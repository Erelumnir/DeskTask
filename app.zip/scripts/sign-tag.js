const { execSync } = require("child_process");
const { version } = require("../package.json");

const tag = `v${version}`;

try {
  console.log(`✍️ Re-signing tag ${tag}...`);
  execSync(`git tag -d ${tag}`, { stdio: "inherit" });
} catch {
  console.log(`ℹ️ Tag ${tag} did not exist or already deleted`);
}

try {
  execSync(`git tag -s ${tag} -m "Release ${tag}"`, { stdio: "inherit" });
  console.log("✅ Tag signed.");
} catch (e) {
  console.error("❌ Failed to sign tag. Is GPG configured?");
  process.exit(1);
}
